package global.sesoc.sample.controller;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import global.sesoc.sample.dao.NoticeDAO;
import global.sesoc.sample.util.FileService;
import global.sesoc.sample.vo.Notice;

/**
 * 사용자 입력을 받아 처리
 */
@Controller
@RequestMapping(value="/notice")
public class NoticeController {
	
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

	//저장경로 선언
	private final String uploadPath="/uploadFile";
	
	@Autowired
	private NoticeDAO dao;
	
	
	@RequestMapping(value="/noticeList", method=RequestMethod.GET)
	public String noticeList(Model model) {
		logger.info("/noticeList start ");
		ArrayList<Notice> list =null;
		
		list=dao.noticeSelectList();
		logger.info("/noticeList-dao.noticeSelectList();후의 list :{} ",list);		
		model.addAttribute("list", list);
		
		return "/notice/noticeList";
	}

	
	@RequestMapping(value="noticeInsertForm", method=RequestMethod.GET)
	public String noticeInsertForm() {
		logger.info("/noticeInsertForm gogo ");
		return "/notice/noticeInsertForm";
	}
	
	
	@RequestMapping(value="/noticeInsert", method=RequestMethod.POST)
	public String noticeInsert(Notice notice, MultipartFile upload){
		logger.info("noticeInsert 스타트");
		logger.info("noticeInsert- notice : {} ",notice);
		logger.info("noticeInsert- upload : {} ",upload);		
		
		//step1.file upload여부 확인조건문
		if(!upload.isEmpty()) {
			String savedfile= FileService.saveFile(upload, uploadPath);
			logger.info("noticeInsert- savedfile :{} ",savedfile);						
			
			//step2.업로드 된 파일의 경로를 VO에게 설정
			notice.setNotice_savedfile(savedfile);						//DB쪽에서 저장한 파일명
			notice.setNotice_originfile(upload.getOriginalFilename());	//원본 파일명(사용자 지정파일명)

		}
			
		//step3.VO를 DB에 Insert
		int count = dao.noticeInsert(notice);
		
		if(count == 0) {
			logger.info("noticeInsert- 저장실패 ");					
		}
		else if(count == 1) {
			logger.info("noticeInsert- 저장성공 ");					
		} 
		return "redirect:noticeList";
	}
	
	
	
	
	
}
