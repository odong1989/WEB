package global.sesoc.sample.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import global.sesoc.sample.controller.NoticeController;
import global.sesoc.sample.vo.Notice;

/**
 * 개인정보 관련 DB처리를 담당
 */
@Repository
public class NoticeDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(NoticeDAO.class);
	
	@Autowired
	private SqlSession session;
	
	public int noticeInsert(Notice notice) {
	logger.info("NoticeDAO-noticeInsert notice : {}",notice);
		int count =0;
		 try {
			 NoticeMapper mapper = session.getMapper(NoticeMapper.class);
			 count = mapper.noticeInsert(notice);
		 }catch(Exception e) {
			 e.printStackTrace();
		 }
		 return count;
	}
	
	public ArrayList<Notice> noticeSelectList(){
		logger.info("NoticeDAO-noticeSelectList 시작");
		ArrayList<Notice> list=null;

		try {
		NoticeMapper mapper = session.getMapper(NoticeMapper.class);
		list = mapper.noticeSelectList();
		logger.info("NoticeDAO-noticeSelectList -list수신결과 : {}",list);
		}
		catch(Exception e){
		logger.info("NoticeDAO-예외처리 발생");
			 e.printStackTrace();			
		}
		logger.info("NoticeDAO-noticeSelectList -list 최종리턴 내용: {}",list);		
		return list;
	}
	
}
