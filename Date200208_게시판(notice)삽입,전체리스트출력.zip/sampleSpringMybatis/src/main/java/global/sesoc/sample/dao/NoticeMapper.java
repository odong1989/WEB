package global.sesoc.sample.dao;

import java.util.ArrayList;

import global.sesoc.sample.vo.Notice;

public interface NoticeMapper {
	
//	<insert id="noticeInsert" parameterType="notice">
	public int 	  noticeInsert(Notice notice);
//	<select id="noticeSelectList" resultType="notice">
// 	나의 실수 : 리턴이 notice라고 notice라고 한것(1개만 돌려주는게 아니니까)
	public ArrayList<Notice> noticeSelectList();
	
}
