package global.sesoc.sample.vo;

import lombok.Data;

@Data
public class Notice {
/*
	create table notice(
	  notice_no            number             primary key
	  ,notice_title          varchar2(50)      not null
	  ,notice_context    varchar2(2000)  not null
	  ,notice_name       varchar2(50)      not null 
	  ,notice_hits          number              default 0
	  ,notice_indate      date                   default sysdate
	  ,notice_savedfile  varchar2(200)    
	  ,notice_originfile  varchar2(200) 
	);
	create sequence notice_seq;
 */
	
	private int    notice_no;
	private String notice_title;
	private String notice_context;
	private String notice_name; 
	
	private int    notice_hits;
	private String notice_indate;
	private String notice_savedfile;    
	private String notice_originfile; 	
}
