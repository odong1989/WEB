package com.test.test;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		logger.info("{}", "home");
		return "home";
	}
	
	@RequestMapping(value = "test1", method = RequestMethod.GET)
	@ResponseBody
	public void test1(String id, String name) {
		logger.info(id);
		logger.info(name);
	}
	
	@RequestMapping(value = "test2", method = RequestMethod.POST)
	@ResponseBody
	public void test2(TestVO vo) {
		logger.info(vo.getId());
		logger.info(vo.getName());
	}
	
	@RequestMapping(value = "test3", method = RequestMethod.POST)
	@ResponseBody
	public void test3(@RequestBody TestVO vo) {
		logger.info(vo.getId());
		logger.info(vo.getName());
	}
	
	@RequestMapping(value = "test4", method = RequestMethod.POST)
	@ResponseBody
	public void test4(TestVO vo) {
		logger.info(vo.getId());
		logger.info(vo.getName());
	}

	@RequestMapping(value = "test5", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<TestVO> test5() {
		ArrayList<TestVO> list = new ArrayList<>();
		list.add(new TestVO("aaa", "111"));
		list.add(new TestVO("bbb", "222"));
		list.add(new TestVO("ccc", "333"));
		list.add(new TestVO("ddd", "444"));
		
		return list;
	}
}
