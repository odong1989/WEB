package com.sesoc.moneybook.vo;

public class MoneybookVO {

}
