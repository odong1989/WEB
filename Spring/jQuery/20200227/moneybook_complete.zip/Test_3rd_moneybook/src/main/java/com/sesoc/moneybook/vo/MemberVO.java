package com.sesoc.moneybook.vo;

import lombok.Data;

@Data
public class MemberVO {

	private String userid;
	private String userpwd;
}
