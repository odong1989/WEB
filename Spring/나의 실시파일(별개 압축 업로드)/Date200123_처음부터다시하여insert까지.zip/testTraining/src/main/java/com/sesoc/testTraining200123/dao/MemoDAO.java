package com.sesoc.testTraining200123.dao;

//틀림 8 sqlsession 임포트 않았음 <-롬복 임포트하듯이 마이바티스도 임포트 합시다!!!
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//틀림11 vo패키지 임포트!!!
import com.sesoc.testTraining200123.vo.MemoVO;

//틀림6 @Repository 미작성
@Repository
public class MemoDAO {

	//틀림 7 전체 미작성--------------------------------------------------
	@Autowired
	private SqlSession session;
	
	public int insertMemo (MemoVO memo){
		int resultCommit=0;
		try {
			MemoMapper mapper = session.getMapper(MemoMapper.class);
			resultCommit = mapper.insertMemo(memo);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return resultCommit;
	}
	//틀림 7 전체 미작성--------------------------------------------------	
}
