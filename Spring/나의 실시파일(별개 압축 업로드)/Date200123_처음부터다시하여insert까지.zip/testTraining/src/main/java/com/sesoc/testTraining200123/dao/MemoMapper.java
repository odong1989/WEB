package com.sesoc.testTraining200123.dao;


import com.sesoc.testTraining200123.vo.MemoVO;//내 틀림1
 
public interface MemoMapper {
	public int insertMemo (MemoVO memo);
}
