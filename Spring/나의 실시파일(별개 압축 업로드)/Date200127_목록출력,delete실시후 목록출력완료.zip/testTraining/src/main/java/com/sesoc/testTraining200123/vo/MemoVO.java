package com.sesoc.testTraining200123.vo;

import lombok.Data;

@Data
public class MemoVO {
	
	private int		 memo_no;
	private String   memo_pw; 
	private String	 memo_content;
	private String 	 memo_indate;

}
