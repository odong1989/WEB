package global.sesoc.sample.dao;

import global.sesoc.sample.vo.Notice;

public interface NoticeMapper {
	
	//Person 객체의 값을 DB에 저장
	public int noticeInsert(Notice notice);

}
