package global.sesoc.sample.dao;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import global.sesoc.sample.controller.NoticeController;
import global.sesoc.sample.vo.Notice;


/**
 * 개인정보 관련 DB처리를 담당
 */
@Repository
public class NoticeDAO {

	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
	@Autowired
	private SqlSession session;
	
	public int noticeInsert(Notice notice) {
		int count =0;
		try {
			NoticeMapper mapper = session.getMapper(NoticeMapper.class);
			count = mapper.noticeInsert(notice);
		}catch(Exception e) {
			e.printStackTrace();
			//파일을 삭제(물리적) -인셉션이 발생하면 실시.
		}
		return count;
	}
	
	
//	public ArrayList<Notice> noticeSelectList(){
	//페이징을 할 수 있도록 변경합니다. 파라미터 2개를 추가합니다.
	public ArrayList<Notice> noticeSelectList(String searchText, int startRecord, int countPerPage){
		ArrayList<Notice> list = null;
		try {
			NoticeMapper mapper = session.getMapper(NoticeMapper.class);
			//2020.02.03. 페이징 위해 추가되었다.
			//RowBounds 객체 = 페이징 처리를 도와주는 마이바티스 객체이다.
			//객체 생성시 시작위치, 보여줄 글 개수를 생성자에 전달해준다.
			//쿼리를 있는 그대로 사용하기 위해서 RowBounds를 씁니다.
			RowBounds rb = new RowBounds(startRecord, countPerPage);//시작할 페이지, 출력할 페이지 개수만 알려주면 알아서 페이징 해줍니다(#쿼리 손 안대도 됨)
			//선생님 한줄평 : 무조건 외우세요! 잊으면 안됩니다!
			list = mapper.noticeSelectList(searchText,rb);
		}catch(Exception e) {
			e.printStackTrace();
		}
		logger.info("noticeSelectList() list : {}", list);
		return list;
	}
	
	public Notice   noticeSelectOne(int notice_no) {
		Notice notice = null;
		try {
			NoticeMapper mapper = session.getMapper(NoticeMapper.class);
			notice = mapper.noticeSelectOne(notice_no);
		}catch(Exception e) {
			e.printStackTrace();
			//파일을 삭제(물리적) -인셉션이 발생하면 실시.
		}
		logger.info("noticeSelectOne() notice : {}", notice);		
		return notice;	
	}
	
	public int noticeUpdate(Notice notice){
		int count =0;
		try {
			NoticeMapper mapper = session.getMapper(NoticeMapper.class);
			count = mapper.noticeUpdate(notice);
		}catch(Exception e) {
			e.printStackTrace();
			//파일을 삭제(물리적) -인셉션이 발생하면 실시.
		}
		return count;
	}
	
	public int noticeSelectCount(String searchText) {
		int count =0;
		try {
			NoticeMapper mapper = session.getMapper(NoticeMapper.class);
			count = mapper.noticeSelectCount(searchText);
		}catch(Exception e) {
			e.printStackTrace();
			//파일을 삭제(물리적) -인셉션이 발생하면 실시.
		}
		//전체 글의 개수를 리턴해줍니다.
		return count;	
	}
	
	
	public void updateHits(int notice_no) {
		try {
			NoticeMapper mapper = session.getMapper(NoticeMapper.class);
			 mapper.updateHits(notice_no);
		}catch(Exception e) {
			e.printStackTrace();
			//파일을 삭제(물리적) -인셉션이 발생하면 실시.
		}
	}
}
