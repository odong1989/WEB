package global.sesoc.sample.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;

import global.sesoc.sample.vo.Notice;

public interface NoticeMapper {
	
	//Person 객체의 값을 DB에 저장
	public int noticeInsert(Notice notice);
	
	//조회 관련
	public ArrayList<Notice> noticeSelectList(String searchText, RowBounds rb );
	public Notice  noticeSelectOne(int notice_no);
	public int noticeSelectCount(String searchText);
	
	//업뎃관련
	public int noticeUpdate(Notice notice);
	public void updateHits(int notice_no);
	
}
