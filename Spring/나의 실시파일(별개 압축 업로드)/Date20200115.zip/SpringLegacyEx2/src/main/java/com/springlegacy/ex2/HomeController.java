package com.springlegacy.ex2;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value="JstlCore", method=RequestMethod.GET)
	public String JstlCore(Model model) {
		int number = 1;
		String str = "abc";
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("aaa");
		list.add("bbb");
		list.add("ccc");
		
		String phone = "010-1111-2222";
		String data = "<marquee>문자열</marquee>";
		
		model.addAttribute("number", number);
		model.addAttribute("str", str);
		model.addAttribute("list", list);
		model.addAttribute("phone", phone);
		model.addAttribute("data", data);
		
		return "jstlCore";
		
	}


		@RequestMapping(value="Session1", method=RequestMethod.GET)
		public String Session1(HttpSession session,Model model) {
			session.setAttribute("id", "admin"); //id가 admin이고
			model.addAttribute("pw", "password");//비밀번호가 password인 사람이 로그인했다고 가정합시다.
			return "Session1";
		}	


		@RequestMapping(value="SessionCheck", method=RequestMethod.GET)
		public String SessionCheck(HttpSession session) {
			//로그인을 했는지 확인하는 페이지입니다.
			//로그인한 사람만 접속할 수 있는 페이지인 것이지요
			//세션에 id의 값이 있는지를 확인합니다.
			//세션은 id+기본적인 정보를 갖고있으며 이를 체크합니다.
			//요청을 보내는 리퀘스트에서 지역을 체크합니다.(#가끔식 타국에서 네가 접속한거냐 묻는 메일에 대해서)

			//session에 id값이 있는지를 확인.
			String id=(String)session.getAttribute("id"); 
			//Obejct형인 이유는 최상위형으로 하여 어떤값을 넣어도 모두 대응하기 위해서.
			//그래서 (String)으로 형변환을 합니다.
			
			if(id ==null) {
				//저장된 id값 없다 = 로그인안했다.
				//로그인 페이지로 이동시키면서 메시지 출력.
			}else {
				//로그인을 했다.
				//정상적으로 페이지를 이동.
			}
			
			return"SessionCheck";
		}
		
		@RequestMapping(value="SessionDelete", method=RequestMethod.GET)
		public String SessionDelete(HttpSession session) {
			session.removeAttribute("id"); //id라는 값이 있다면 id라는 녀석이 보관중인 값을 지워라.
			//remove : 1개만 지웁니다.
			//invalidate : 모조리 싹! 다 지움(쓰지않길 권합니다. 포맷급 초기화할 때만 쓰세요!)	
			return "Session1";
		}
}
