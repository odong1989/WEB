package com.springlegacy.ex2.vo;

import lombok.Data;

@Data
public class Member {
	private String id;
	private String password;
	private int age;
	private String name;
}
