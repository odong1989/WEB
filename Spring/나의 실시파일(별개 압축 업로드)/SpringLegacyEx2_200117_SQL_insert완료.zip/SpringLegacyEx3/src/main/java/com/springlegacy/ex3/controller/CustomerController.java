package com.springlegacy.ex3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springlegacy.ex3.dao.CustomerDAO;
import com.springlegacy.ex3.vo.Customer;

@Controller
public class CustomerController {

	@Autowired
	private CustomerDAO dao;
	
	@RequestMapping(value="joinForm", method = RequestMethod.GET)
	public String joinForm() {
		return"joinForm";
	}
		
	@RequestMapping(value="join", method=RequestMethod.POST)
	public String insertCustomer(Customer customer) {
	//public String insertCustomer(Customer customer,Model model) {
		

	//	model.addAttribute("custid",customer.getCustid());
	//	model.addAttribute("name",customer.getName());
		dao.insertCustomer(customer);
		System.out.println(customer);
	//	return "result";
		return "home";
	}
	
	
	
	
	
	
	
	
	
}
