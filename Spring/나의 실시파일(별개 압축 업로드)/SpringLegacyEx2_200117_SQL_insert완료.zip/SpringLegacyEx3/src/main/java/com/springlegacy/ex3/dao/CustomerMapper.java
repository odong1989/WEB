package com.springlegacy.ex3.dao;

import com.springlegacy.ex3.vo.Customer;

public interface CustomerMapper {
	
	public int insertCustomer(Customer customer);
	
	
}
