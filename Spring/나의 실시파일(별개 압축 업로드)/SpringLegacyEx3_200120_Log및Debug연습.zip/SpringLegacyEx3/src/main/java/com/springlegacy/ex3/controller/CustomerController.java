package com.springlegacy.ex3.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springlegacy.ex3.HomeController;
import com.springlegacy.ex3.dao.CustomerDAO;
import com.springlegacy.ex3.vo.Customer;

@Controller
public class CustomerController {
	//2020.01.20 디버깅학습
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	//
	
	@Autowired
	private CustomerDAO dao;
		
	@RequestMapping(value="join", method=RequestMethod.POST)
	public String insertCustomer(Customer customer) {
		logger.info("디버깅-브레이크 포인트 설정입니다");
		//디버깅 : 화면으로 넘어오는 값을 확인하는 과정이며 이를 위해 브레이크 포인트를 실시합니다.
		
		//2020.01.20 디버깅학습
		logger.info("회원가입 컨트롤러 시작되었씁니다.");
		
		int cnt = dao.insertCustomer(customer);
		
		if(cnt>0) {
			logger.info("회원가입성공, 쿼리 출력값:{}",cnt);
			//	System.out.println("회원가입성공");

			//단순히 출력만따지면 System.out.println과 log는 다르지 않아요.
			//개발단계에 있는 콘솔에만 찍히느냐, 
			//서버에도 찍히고, 출력물로도 남느냐
			//그로인해 사용자에게 보이지 ㅇ낳도록 하려고 일일이 지우고 난리르 치는 시간을 절약하느냐,
			//또한 
		}
		else {
			logger.info("회원가입실패, 쿼리 출력값:{}",cnt);
			//System.out.println("회원가입실패");
			return "redirect:joinForm";
			// 실패하였다면 회워가입폼으로 다시돌아간다.
			// 리다이렉트를 하면 다른웹페이지로 이동하면서 부가적으로 기존의 정보를 지울 수 있도록 합니다
		}
		return "redirect:/";
		//단 톰캣을 더블 클릭후 Modules에서 /ex3를 클릭-> edit를 통해 / 으로 수정한다.

	}
		
		
		//
		
		/*1교시 학습한 부분(디버깅 학습 위해 주석처리.)
		int cnt = dao.insertCustomer(customer);
		System.out.println(customer);
		
		if(cnt>0) {
			System.out.println("회원가입성공");
		}
		else {
			System.out.println("회원가입실패");
			return "redirect:joinForm";
			// 실패하였다면 회워가입폼으로 다시돌아간다.
			// 리다이렉트를 하면 다른웹페이지로 이동하면서 부가적으로 기존의 정보를 지울 수 있도록 합니다
		 return"redirect:/";
		//단 톰캣을 더블 클릭후 Modules에서 /ex3를 클릭-> edit를 통해 / 으로 수정한다.
		} */
	
}
