package com.springlegacy.ex3.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springlegacy.ex3.vo.Customer;

@Repository
public class CustomerDAO {

	//SqlSessionFactory로 부터 Sqlsession객체를 가져오는 코드
	//SQL 관련 세션(커밋등)을 마이바티스처럼 일일이 작성하지 않습니다.
	//알아서 다하니까요. 오히려 사용자가 작성해주면 그거때문에 에러남..
	@Autowired
	private SqlSession session;
	
	public int insertCustomer(Customer customer) {
		int cnt = 0;
		try {
			CustomerMapper mapper = session.getMapper(CustomerMapper.class);
			cnt = mapper.insertCustomer(customer);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
}
