package global.sesoc.sample.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import global.sesoc.sample.dao.NoticeDAO;
import global.sesoc.sample.util.FileService;
import global.sesoc.sample.vo.Notice;

/**
 * 사용자 입력을 받아 처리
 */
@Controller
@RequestMapping(value="/notice")
public class NoticeController {
	
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

	private final String uploadPath = "/uploadFile";
	
	@Autowired
	private NoticeDAO dao;

	@RequestMapping(value="/noticeList", method=RequestMethod.GET)
	public String noticeList() {
		logger.info("게시글 목록 페이지 이동");
		return "notice/noticeList";
	}
	
	@RequestMapping(value="/noticeInsertForm", method=RequestMethod.GET)
	public String noticeInsertForm() {
		logger.info("게시글 등록 폼 이동");
		return "notice/noticeInsertForm";
	}
	
	@RequestMapping(value="/noticeInsert", method=RequestMethod.POST)
	public String noticeInsert(Notice notice,MultipartFile upload) {
		
		//파일업로드(물리적)
		//파일이 있을때
		if(!upload.isEmpty()) {
			String savedfile = FileService.saveFile(upload, uploadPath);
			//업로드된 파일의 경로(파일명)을 VO에 SET
			//저장된 파일명
			notice.setNotice_savedfile(savedfile);
			//원본 파일명
			notice.setNotice_originfile(upload.getOriginalFilename());
		}
		//VO를 DB에 INSERT
		int count = dao.noticeInsert(notice);
		
		if(count == 0) {
			logger.info("등록 실패");
			//파일을 삭제(물리적)
		}
		
		
		return "redirect:noticeList";
	}
	
	
	
	
	
	
}
