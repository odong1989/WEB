package global.sesoc.sample.dao;

import global.sesoc.sample.vo.Notice;

public interface NoticeMapper {
	
	public int noticeInsert(Notice notice);
}
