package com.springlegacy.ex1.vo;

import lombok.Data;

@Data
public class TestDataLB {
	private String str;
	private String password;
	private String[] hobby;
}
