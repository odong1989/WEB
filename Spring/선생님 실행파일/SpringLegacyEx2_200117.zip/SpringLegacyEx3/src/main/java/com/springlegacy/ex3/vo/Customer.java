package com.springlegacy.ex3.vo;

import lombok.Data;

@Data
public class Customer {

	private String custid;
	private String password;
	private String name;
	private String email;
	private String division;
	private String idno;
	private String address;
	
}
