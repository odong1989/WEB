package com.springlegacy.homework.vo;

import lombok.Data;

@Data
public class Memo {
	private int memo_no;
	private String memo_pw;
	private String memo_content;
	private String memo_indate;
}
