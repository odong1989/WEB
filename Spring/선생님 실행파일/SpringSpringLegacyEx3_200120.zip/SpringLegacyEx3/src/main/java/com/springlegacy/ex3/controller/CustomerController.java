package com.springlegacy.ex3.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springlegacy.ex3.HomeController;
import com.springlegacy.ex3.dao.CustomerDAO;
import com.springlegacy.ex3.vo.Customer;

@Controller
public class CustomerController {
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	private CustomerDAO dao;
	
	@RequestMapping(value="join", method=RequestMethod.POST)
	public String insertCustomer(Customer customer) {
		logger.info("회원가입 컨트롤러 시작");
		
		int cnt = dao.insertCustomer(customer);
		
		if(cnt > 0) {
			logger.info("회원가입 성공, 쿼리 출력값 : {}", cnt);
		} else {
			logger.info("회원가입 실패, 쿼리 출력값 : {}", cnt);
			return "redirect:joinForm";
		}
		
		logger.info("회원가입 컨트롤러 종료");
		return "redirect:/";
	}
	
	
	
	
	
	
	
	
	
}
