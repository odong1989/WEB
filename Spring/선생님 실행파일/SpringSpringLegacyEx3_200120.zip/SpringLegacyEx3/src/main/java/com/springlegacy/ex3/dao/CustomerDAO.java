package com.springlegacy.ex3.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springlegacy.ex3.vo.Customer;

@Repository
public class CustomerDAO {

	//SqlSessionFactory로 부터 Sqlsession객체를 가져오는 코드
	@Autowired
	private SqlSession session;
	
	public int insertCustomer(Customer customer) {
		int cnt = 0;
		try {
			CustomerMapper mapper = session.getMapper(CustomerMapper.class);
			cnt = mapper.insertCustomer(customer);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}
	
}
