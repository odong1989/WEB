-- 고객 정보 테이블
create table customer (
	custid		varchar2(20) primary key,	--고객 아이디
	password	varchar2(20) not null,		--비밀번호
	name		varchar2(30) not null,		--고객 이름
	email		varchar2(30),				--고객 이메일
	division	varchar2(30) not null,		--고객구분 : personal(개인), company(기업)
	idno		varchar2(20) unique,	 	--식별번호 (개인: 주민번호, 법인: 사업자 번호)	
	address		varchar2(100)				--주소
);