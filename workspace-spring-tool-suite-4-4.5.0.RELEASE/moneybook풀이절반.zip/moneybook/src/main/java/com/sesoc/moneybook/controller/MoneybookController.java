package com.sesoc.moneybook.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sesoc.moneybook.vo.MoneybookVO;

@Controller
public class MoneybookController {
	
	// 가계부 화면 이동
	@RequestMapping(value = "moneybookList", method = RequestMethod.GET)
	public String moneybookList() {
		return "moneybookList";
	}
	
	// 가계부 등록
	@RequestMapping(value = "write", method = RequestMethod.GET)
	@ResponseBody
	public void write(MoneybookVO vo, HttpSession session) {
		String userid = (String)session.getAttribute("userid");
		vo.setUserid(userid);
	}
}




