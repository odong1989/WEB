package com.sesoc.moneybook.dao;

import com.sesoc.moneybook.vo.MoneybookVO;

public interface MoneyBookMapper {

	public void write(MoneybookVO vo); 
}
